package com.example.myapplication

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.data.entity.Category
import com.example.myapplication.ui.theme.GourmetManagerTheme
import com.example.myapplication.ui.theme.Poppins
import com.example.myapplication.ui.theme.blue
import com.example.myapplication.ui.theme.disabledButtonColor
import com.example.myapplication.ui.theme.grey
import com.example.myapplication.ui.theme.white
import com.example.myapplication.ui.theme.yellow

//screen to edit a category
@Composable
fun EditCategoryScreen (
    category: Category,
    viewModel: AppViewModel,
    navController: NavController,
    modifier: Modifier = Modifier
) {

    var name by remember { mutableStateOf(category.name) }
    var isNameValid by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = grey
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            Text(
                text = stringResource(R.string.fill_details),
                style = MaterialTheme.typography.bodyLarge,
                color = blue,
                modifier = Modifier.padding(top = 32.dp, start = 16.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            NameField(
                name = name,
                isNameValid = isNameValid,
                label = "Nome da categoria",
                onValueChange = {
                    name = it
                    isNameValid = it.isNotBlank()
                })

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                EditCategoryButton(
                    enabled = isNameValid,
                    name = name,
                    category = category,
                    navController = navController,
                    viewModel = viewModel
                )
            }

        }
    }
}

@Composable
fun EditCategoryButton(
    enabled : Boolean,
    name: String,
    category: Category,
    navController: NavController,
    viewModel: AppViewModel
) {

    Button(
        onClick = {
            val updatedCategory = Category(category.id, name)
            viewModel.updateCategory(updatedCategory)
            navController.navigate(GourmetManagerScreen.Menu.name)
        },
        colors = ButtonDefaults.buttonColors(
            containerColor = blue,
            disabledContainerColor = disabledButtonColor
        ),
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .wrapContentHeight()
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(id = R.string.change),
            color = white,
            style = MaterialTheme.typography.labelSmall
        )
    }
}


@Preview
@Composable
fun EditCategoryPreview() {
    GourmetManagerTheme {
        

        EditCategoryScreen(
            category = selectedCategory,
            navController = rememberNavController(),
            viewModel = AppViewModel(Application()),
            modifier = Modifier
                .fillMaxSize()
        )
    }
}