package com.example.myapplication

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.ui.theme.blue
import com.example.myapplication.ui.theme.disabledButtonColor
import com.example.myapplication.ui.theme.grey


//screen to see the details of a selected employee
@Composable
fun EmployeeDetailsScreen(
    navController: NavController,
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val selectedEmployee by viewModel::selectedEmployee
    Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row {
                    Column {
                        Spacer(
                            modifier
                                .padding(16.dp)
                        )
                        Text(
                            text = "Nº de funcionário",
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = "Nome",
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = "Nome de utilizador",
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = "E-mail",
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = "Administrador",
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Spacer(modifier.padding(24.dp))
                    }
                    Column {
                        Spacer(
                            modifier
                                .padding(16.dp)
                        )
                        Text(
                            text = selectedEmployee.id.toString(),
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = selectedEmployee.name,
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = selectedEmployee.username,
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Text(
                            text = selectedEmployee.email,
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        val text = if (selectedEmployee.admin) {
                            "Sim"
                        } else {
                            "Não"
                        }
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = blue,
                            modifier = modifier.padding(8.dp)
                        )
                        Spacer(modifier.padding(24.dp))
                    }
                }
                if (!selectedEmployee.admin) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                viewModel.deactivateEmployee(selectedEmployee.id)
                                navController.navigate(GourmetManagerScreen.Employees.name)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = blue,
                                disabledContainerColor = disabledButtonColor
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .wrapContentHeight()
                                .padding(start = 16.dp)

                        ) {
                            Text("Eliminar", style = MaterialTheme.typography.labelSmall)
                        }
                        Button(
                            onClick = {
                                viewModel.makeEmployeeAdmin(selectedEmployee.id)
                                navController.navigate(GourmetManagerScreen.ViewEmployeeDetails.name)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = blue,
                                disabledContainerColor = disabledButtonColor
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .wrapContentHeight()
                                .padding(end = 16.dp)

                        ) {
                            Text("Fazer administrador", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
