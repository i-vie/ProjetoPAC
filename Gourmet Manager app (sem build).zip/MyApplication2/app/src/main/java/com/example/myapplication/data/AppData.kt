package com.example.myapplication.data

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import com.example.myapplication.AppViewModel
import com.example.myapplication.data.entity.Order
import java.util.Calendar

    class Reservation(
        val reservationNr: Int,
        val nrPeople: Int,
        val tableNr: String,
        val date: String
    )

    val reservation1 = Reservation(1, 4, "Mesa 2", "")
    val reservation2 = Reservation(2, 5, "Mesa 3", "getTime()")
    val reservation3 = Reservation(3, 3, "Mesa 1", "getTime()")
    val reservation4 = Reservation(4, 2, "Mesa 4", "getTime()")
    val reservation5 = Reservation(5, 8, "Mesa 7", "getTime()")

    val reservations = listOf(
        reservation1,
        reservation2,
        reservation3,
        reservation4,
        reservation5,
        reservation1,
        reservation2
    )


    fun saveLoginState(context: Context, isLoggedIn: Boolean) {
        val sharedPref = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("isLoggedIn", isLoggedIn)
            apply()
        }
    }

    fun clearUserInfo(context: Context) {
        val sharedPref = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("isLoggedIn", false)
            remove("userId")
            remove("userName")
            apply()
        }
    }

    fun isUserLoggedIn(context: Context): Boolean {
        val sharedPref = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        return sharedPref.getBoolean("isLoggedIn", false)
    }

    fun getUserId(context: Context): String? {
        val sharedPref = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        return sharedPref.getString("userId", null)
    }

    fun getUserName(context: Context): String? {
        val sharedPref = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        return sharedPref.getString("userName", null)
    }

    fun saveUserInfo(context: Context, userId: String, userName: String) {
        val sharedPref = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("isLoggedIn", true)
            putString("userId", userId)
            putString("userName", userName)
            apply()
        }
    }

