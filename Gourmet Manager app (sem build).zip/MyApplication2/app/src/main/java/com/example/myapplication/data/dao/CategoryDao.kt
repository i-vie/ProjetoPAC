package com.example.myapplication.data.dao

import androidx.room.*
import com.example.myapplication.data.entity.Category

@Dao
interface CategoryDao {
    @Insert
    suspend fun insert(category: Category)
    @Query("SELECT * FROM category WHERE active = 1")
    suspend fun getAllCategories(): List<Category>
    @Delete
    suspend fun delete(category: Category)
    @Update
    suspend fun update(category: Category)
    @Query("SELECT * FROM category WHERE id = :selectedCategoryID")
    suspend fun getCategoryById(selectedCategoryID: Int): Category?
    @Query("UPDATE category SET active = 0 WHERE id = :categoryId")
    suspend fun deactivateCategory(categoryId: Int)
}
