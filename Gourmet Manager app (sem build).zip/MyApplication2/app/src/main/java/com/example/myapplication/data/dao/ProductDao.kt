package com.example.myapplication.data.dao

import androidx.room.*
import com.example.myapplication.data.entity.Category
import com.example.myapplication.data.entity.Order
import com.example.myapplication.data.entity.Product

@Dao
interface ProductDao {

    @Insert
    suspend fun insert(product: Product)

    @Query("SELECT * FROM product WHERE categoryId = :categoryId AND active = 1")
    suspend fun getProductsFromCategory(categoryId: Int): List<Product>

    @Query("SELECT * FROM product WHERE id = :productId")
    suspend fun getProductById(productId: Int): Product?

    @Delete
    suspend fun delete(product: Product)

    @Update
    suspend fun update(product: Product)

    @Query("SELECT * FROM product WHERE active = 1")
    suspend fun getActiveProducts(): List<Product>

    @Query("UPDATE product SET active = 0 WHERE id = :productId")
    suspend fun deactivateProduct(productId: Int)

}