package com.example.myapplication.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "table_count")
data class TableCount(
    @PrimaryKey(autoGenerate = true) val id: Int = 1,
    val totalTables: Int
)