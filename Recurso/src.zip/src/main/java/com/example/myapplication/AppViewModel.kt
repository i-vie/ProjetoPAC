package com.example.myapplication

import android.app.Application
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.AppDatabase
import com.example.myapplication.data.entity.Category
import com.example.myapplication.data.entity.Employee
import com.example.myapplication.data.entity.Order
import com.example.myapplication.data.entity.OrderItem
import com.example.myapplication.data.entity.Product
import com.example.myapplication.data.entity.Reservation
import com.example.myapplication.data.entity.TableCount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

class AppViewModel(application: Application) :
    AndroidViewModel(application) {

    private val _darkTheme = MutableStateFlow<Boolean>(false)
    val darkTheme: StateFlow<Boolean> = _darkTheme

    fun setTheme(darkTheme: Boolean) {
        viewModelScope.launch {
            _darkTheme.value = darkTheme
        }
    }


    //Orders

    private val _totalOrdersToday = MutableStateFlow<Int>(0)
    val totalOrdersToday: StateFlow<Int> = _totalOrdersToday
    private val _totalOpenOrdersToday = MutableStateFlow<Int>(0)
    val totalOpenOrdersToday: StateFlow<Int> = _totalOpenOrdersToday
    private val _totalClosedOrdersToday = MutableStateFlow<Int>(0)
    val totalClosedOrdersToday: StateFlow<Int> = _totalClosedOrdersToday
    private val _totalOrdersPriceToday = MutableStateFlow<Double>(0.0)
    val totalOrdersPriceToday: StateFlow<Double> = _totalOrdersPriceToday
    private val _selectedOrder = MutableStateFlow<Order?>(null)
    val selectedOrder: StateFlow<Order?> = _selectedOrder


    //gets the start of the current day
    fun getStartOfDayInMillis(dayInMillis: Long): Long {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = dayInMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    //gets the end of the current day
    fun getEndOfDayInMillis(dayInMillis: Long): Long {
        val calendar = Calendar.getInstance().apply {
            timeInMillis = dayInMillis
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        return calendar.timeInMillis
    }


    //total open order in the current day
    fun getTotalOpenOrdersToday() {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(System.currentTimeMillis())
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _totalOpenOrdersToday.value = orderDao.totalOpenOrdersToday(startOfDay, endOfDay)
        }
    }

    //total closed order in the current day
    fun getTotalClosedOrdersToday() {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(System.currentTimeMillis())
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _totalClosedOrdersToday.value = orderDao.totalClosedOrdersToday(startOfDay, endOfDay)
        }
    }

    //total price of orders of the current day
    fun getTotalOrdersPriceToday() {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(System.currentTimeMillis())
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            var price = 0.0
            if (_totalClosedOrdersToday.value != 0) {
                price = orderDao.totalOrdersPriceToday(startOfDay, endOfDay)
            }
            _totalOrdersPriceToday.value = price
        }
    }

    //total orders in the current day
    fun getTotalOrdersToday() {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(System.currentTimeMillis())
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _totalOrdersToday.value = orderDao.totalOrdersToday(startOfDay, endOfDay)
        }
    }


    fun selectOrder(order: Order) {
        _selectedOrder.value = order
    }

    var selectedTable = mutableStateOf(1)
    var new = mutableStateOf(true)
    var listProducts = mutableStateListOf<Pair<Product, Int>>()
    fun clearOrder() {
        listProducts.clear()
        selectedTable.value = 1
    }

    var selectedEmployee by mutableStateOf(Employee(0, "", "", "", "", admin = false))

    fun updateSelectedEmployee(employee: Employee) {
        selectedEmployee = employee
    }


    //Categories
    private val categoryDao = AppDatabase.getDatabase(application).categoryDao()
    private val _categoryList = MutableStateFlow<List<Category>>(emptyList())
    val categoryList: StateFlow<List<Category>> = _categoryList //list of all categories

    init {
        viewModelScope.launch {
            _categoryList.value = categoryDao.getAllCategories()
        }
    }

    //add new category
    fun addCategory(name: String) {
        viewModelScope.launch {
            categoryDao.insert(Category(name = name))
            _categoryList.value = categoryDao.getAllCategories()
        }
    }

    //update existing category
    fun updateCategory(category: Category) {
        viewModelScope.launch {
            categoryDao.update(category)
            _categoryList.value = categoryDao.getAllCategories()
        }
    }

    //Employee

    private val employeeDao = AppDatabase.getDatabase(application).employeeDao()
    private val _employeeList = MutableStateFlow<List<Employee>>(emptyList())
    val employeeList: StateFlow<List<Employee>> = _employeeList
    private val _employeeResult = MutableStateFlow<Employee?>(null)
    val employeeResult: StateFlow<Employee?> get() = _employeeResult
    private val _passwordCheckResult = MutableStateFlow<Boolean?>(null)
    val passwordCheckResult: StateFlow<Boolean?> get() = _passwordCheckResult
    private val _emailCheckResult = MutableStateFlow<Boolean?>(null)
    val emailCheckResult: StateFlow<Boolean?> get() = _emailCheckResult

    init {
        viewModelScope.launch {
            _employeeList.value = employeeDao.getActiveEmployees()
        }
    }

    fun addEmployee(
        name: String,
        username: String,
        email: String,
        password: String,
        admin: Boolean
    ) {
        viewModelScope.launch {
            employeeDao.insert(
                Employee(
                    name = name,
                    username = username,
                    email = email,
                    password = password,
                    admin = admin
                )
            )
            _employeeList.value = employeeDao.getActiveEmployees()
        }
    }

    //makes a non-admin employee admin
    fun makeEmployeeAdmin(employeeId: Int) {
        viewModelScope.launch {
            selectedEmployee = selectedEmployee.copy(admin = true)
            employeeDao.updateEmployeeAdminStatus(employeeId, true)
        }
    }

    private val _usernameExists = MutableStateFlow(false)
    val usernameExists: StateFlow<Boolean> = _usernameExists
    private val _emailExists = MutableStateFlow(false)
    val emailExists: StateFlow<Boolean> = _emailExists

    //verifies if a username already exists
    fun usernameExists(username: String) {
        viewModelScope.launch {
            _usernameExists.value = employeeDao.usernameExists(username)
        }
    }

    //verifies if an email already exists
    fun emailExists(email: String) {
        viewModelScope.launch {
            _emailExists.value = employeeDao.emailExists(email)
        }
    }

    //deactivates an employee (instead of deleting, we chose to deactivate
    fun deactivateEmployee(employeeId: Int) {
        viewModelScope.launch {
            employeeDao.deactivateEmployee(employeeId)
            _employeeList.value = employeeDao.getActiveEmployees()
        }
    }


    fun checkEmployee(input: String) {
        viewModelScope.launch {
            val employee = employeeDao.getEmployeeByUsernameOrEmail(input)
            _employeeResult.value = employee
        }
    }

    fun checkUsername(input: String) {
        viewModelScope.launch {
            val employee = employeeDao.getEmployeeByUsername(input)
            _employeeResult.value = employee
        }
    }

    fun checkEmail(input: String) {
        viewModelScope.launch {
            _emailCheckResult.value = _employeeResult.value?.email == input
        }
    }

    fun checkPassword(password: String) {
        viewModelScope.launch {
            _passwordCheckResult.value = _employeeResult.value?.password == password
        }
    }

    private val _passwordResult = MutableStateFlow<String>("")
    val passwordResult: StateFlow<String> = _passwordResult

    fun getEmployeePassword(username: String, email: String) {
        viewModelScope.launch {
            val employee = employeeDao.getEmployeeByUsernameOrEmail(username)
            employee?.let {
                if (it.email == email) {
                    _passwordResult.value = it.password
                } else {
                    null
                }
            }
        }
    }

    fun updatePasswordById(employeeId: Int, newPassword: String) {
        viewModelScope.launch {
            _loggedInEmployee.value = _loggedInEmployee.value?.copy(password = newPassword)
            employeeDao.updatePasswordById(employeeId, newPassword)
            _employeeList.value = employeeDao.getActiveEmployees()
        }
    }

    //funcionário com sessão iniciada
    private val _loggedInEmployee = MutableLiveData<Employee?>()
    val loggedInEmployee: MutableLiveData<Employee?> = _loggedInEmployee

    fun setLoggedInEmployee(employee: Employee) {
        _loggedInEmployee.value = employee
    }

    fun clearLoggedInEmployee() {
        _loggedInEmployee.value = null
    }


    private val orderDao = AppDatabase.getDatabase(application).orderDao()
    private val orderItemDao = AppDatabase.getDatabase(application).orderItemDao()

    private val _orderList = MutableStateFlow<List<Order>>(emptyList())
    val orderList: StateFlow<List<Order>> = _orderList
    private val _orderResult = MutableStateFlow<Order?>(null)
    val orderResult: MutableStateFlow<Order?> = _orderResult
    private val _orderItems = MutableStateFlow<List<OrderItem>>(emptyList())
    val orderItems: MutableStateFlow<List<OrderItem>> = _orderItems
    private val _openOrders = MutableStateFlow<List<Order>>(emptyList())
    val openOrders: MutableStateFlow<List<Order>> = _openOrders
    private val _myOrders = MutableStateFlow<List<Order>>(emptyList())
    val myOrders: MutableStateFlow<List<Order>> = _myOrders
    private val _allOrderItem = MutableStateFlow<List<OrderItem>>(emptyList())
    val allOrderItem: MutableStateFlow<List<OrderItem>> = _allOrderItem

    init {
        viewModelScope.launch {
            _orderList.value = orderDao.getAllOrders()
        }
        viewModelScope.launch {
            _allOrderItem.value = orderItemDao.getAllOrderItems()
        }
    }


    //adds an order to the database and all the orderItems
    fun addOrderWithItems(order: Order, orderItems: List<OrderItem>) {
        viewModelScope.launch {

            val orderNr = orderDao.insert(order).toInt()

            orderItems.forEach { it.orderId = orderNr }
            for (item in orderItems) {
                orderItemDao.insert(item)
            }
            _orderList.value = orderDao.getAllOrders()
            _orderItems.value = orderItemDao.getAllOrderItems()
        }
    }

    //updates the order items for an order
    fun updateOrderItems(orderNr: Int, orderItems: List<OrderItem>) {
        viewModelScope.launch {
            val currentOrderItems = orderItemDao.getOrderItemsByOrderId(orderNr)
            for (item in currentOrderItems) {
                orderItemDao.delete(item)
            }
            orderItems.forEach { it.orderId = orderNr }
            for (item in orderItems) {
                if (item.quantity > 0) {
                    orderItemDao.insert(item)
                }
            }
        }
    }

    private val _totalOrders = MutableStateFlow<Int>(0)
    val totalOrders: MutableStateFlow<Int> = _totalOrders
    private val _totalOpenOrders = MutableStateFlow<Int>(0)
    val totalOpenOrders: MutableStateFlow<Int> = _totalOpenOrders
    private val _totalClosedOrders = MutableStateFlow<Int>(0)
    val totalClosedOrders: MutableStateFlow<Int> = _totalClosedOrders
    private val _totalClosedOrdersPrice = MutableStateFlow(0.0)
    val totalClosedOrdersPrice: StateFlow<Double> = _totalClosedOrdersPrice


    fun getTotalOrders() {
        viewModelScope.launch {
            _totalOrders.value = orderDao.totalOrders()
        }
    }

    fun getTotalOpenOrders() {
        viewModelScope.launch {
            _totalOpenOrders.value = orderDao.totalOpenOrders()
        }
    }


    fun closeOrder(orderNr: Int) {
        viewModelScope.launch {
            orderDao.closeOrder(orderNr)
            _totalClosedOrders.value = orderDao.totalClosedOrders()
            _totalOpenOrders.value = orderDao.totalOpenOrders()
            getTotalOrdersToday()
            getTotalClosedOrdersToday()
            getTotalOpenOrdersToday()
        }
    }


    fun deactivateProduct(productId: Int) {
        viewModelScope.launch {
            productDao.deactivateProduct(productId)
            _productList.value = productDao.getActiveProducts()
        }
    }

    fun delete(order: Order) {
        viewModelScope.launch {
            orderItemDao.deleteOrderItems(order.orderNr)
            orderDao.delete(order)
            getTotalOrders()
            getTotalOpenOrders()
            getTotalOrdersToday()
            getTotalOpenOrdersToday()
            _orderList.value = orderDao.getAllOrders()
        }
    }


    fun updateOrderTotal(orderNr: Int, newTotal: Float) {
        viewModelScope.launch {
            orderDao.updateOrderTotal(orderNr, newTotal)
        }
    }

    fun updateOrderTable(orderNr: Int, newTable: Int) {
        viewModelScope.launch {
            orderDao.updateOrderTable(orderNr, newTable)
        }
    }


    private fun deleteOrder(order: Order) {
        viewModelScope.launch {
            orderDao.delete(order)
            _orderList.value = orderDao.getAllOrders()
        }
    }


    private val _orderNr = MutableStateFlow<Int>(0)
    val orderNr: MutableStateFlow<Int> = _orderNr


    //lista de produtos e quantidades por número de pedido
    fun getOrderItemsByOrderId(orderNr: Int) = viewModelScope.launch {
        viewModelScope.launch {
            val orderItems = orderItemDao.getOrderItemsByOrderId(orderNr)
            _orderItems.value = orderItems
        }

    }

    private fun getPriceOrderItem(orderItem: OrderItem): Float {
        viewModelScope.launch {
            getProductById(orderItem.productId)
        }
        val product = productResult.value
        val total = (product?.price ?: 0.0f) * orderItem.quantity
        return total
    }


    //pedidos com estado aberto
    fun getOpenOrders() {
        viewModelScope.launch {
            val orders = orderDao.getOpenOrders()
            _openOrders.value = orders
        }
    }


    //pedidos do funcionário com sessão iniciada
    fun getMyOrders() {
        viewModelScope.launch {
            loggedInEmployee.value?.id?.let { employeeId ->
                val orders = orderDao.getOrdersByEmployeeId(employeeId)
                val sortedOrders = orders.sortedByDescending { it.open }
                _myOrders.value = sortedOrders
            }
        }
    }

    //pedidos do funcionário com sessão iniciada
    fun getAllOrders() {
        viewModelScope.launch {
            val orders = orderDao.getAllOrders()
            val sortedOrders = orders.sortedByDescending { it.open }
            _orderList.value = sortedOrders
        }
    }


    private val productDao = AppDatabase.getDatabase(application).productDao()
    private val _productList = MutableStateFlow<List<Product>>(emptyList())
    val productList: StateFlow<List<Product>> = _productList
    private val _productResult = MutableStateFlow<Product?>(null)
    val productResult: StateFlow<Product?> = _productResult

    init {
        viewModelScope.launch {
            _productList.value = productDao.getActiveProducts()
        }
    }

    fun addProduct(product: Product) {
        viewModelScope.launch {
            productDao.insert(product)
            _productList.value = productDao.getActiveProducts()
        }
    }

    fun updateProduct(product: Product) {
        viewModelScope.launch {
            productDao.update(product)
            _productList.value = productDao.getActiveProducts()
        }
    }

    fun getProductsFromCategory(categoryId: Int) {
        viewModelScope.launch {
            _productList.value = productDao.getProductsFromCategory(categoryId)
        }
    }

    fun getProductById(productId: Int): StateFlow<Product?> {
        val productFlow = MutableStateFlow<Product?>(null)
        viewModelScope.launch {
            val product = productDao.getProductById(productId)!!
            productFlow.value = product
        }
        return productFlow
    }

    private val _categoryResult = MutableStateFlow<Category?>(null)
    val categoryResult: MutableStateFlow<Category?> = _categoryResult

    fun getCategoryById(selectedCategoryID: Int) {
        viewModelScope.launch {
            val order = categoryDao.getCategoryById(selectedCategoryID)
            _categoryResult.value = order
        }
    }

    fun deactivateCategory(category: Category) {
        viewModelScope.launch {
            val productsFromCategory = productDao.getProductsFromCategory(category.id)
            for (product in productsFromCategory) {
                productDao.deactivateProduct(product.id)
            }
            categoryDao.deactivateCategory(category.id)
            _categoryList.value = categoryDao.getAllCategories()
            _productList.value = productDao.getActiveProducts()
        }
    }

    private val tableCountDao = AppDatabase.getDatabase(application).tableCountDao()
    private val _totalTables =
        MutableStateFlow<Int>(10) //initial value of 10 tables, that the user can change
    val totalTables: StateFlow<Int> = _totalTables

    init {
        getTotalTables()
    }

    fun getTotalTables() {
        viewModelScope.launch {

            _totalTables.value = tableCountDao.getTotalTables()
        }
    }

    fun updateTotalTables(newTotal: Int) {
        viewModelScope.launch {
            tableCountDao.insert(TableCount(totalTables = newTotal))
            _totalTables.value = newTotal
        }
    }

    //generates an array according to the number of tables
    fun generateTableArray(total: Int): Array<Int> {
        return Array(total) { index -> index + 1 }
    }

    //RESERVATIONS

    private val _allReservations = MutableStateFlow<List<Reservation>>(emptyList())
    val allReservations: StateFlow<List<Reservation>> = _allReservations
    private val _totalOpenReservationsToday = MutableStateFlow<Int>(0)
    val totalOpenReservationsToday: StateFlow<Int> = _totalOpenReservationsToday
    private val _totalOpenReservations = MutableStateFlow<Int>(0)
    val totalOpenReservations: StateFlow<Int> = _totalOpenReservations
    private val _openReservationsToday = MutableStateFlow<List<Reservation>>(emptyList())
    val openReservationsToday: StateFlow<List<Reservation>> = _openReservationsToday
    private val _reservationResult = MutableStateFlow<Reservation?>(null)
    val reservationResult: MutableStateFlow<Reservation?> = _reservationResult
    private val _openReservations = MutableStateFlow<List<Reservation>>(emptyList())
    val openReservations: StateFlow<List<Reservation>> = _openReservations
    private val _reservationsByDay = MutableStateFlow<List<Reservation>>(emptyList())
    val reservationsByDay: StateFlow<List<Reservation>> = _reservationsByDay
    private val _totalReservationsByDay = MutableStateFlow<Int>(0)
    val totalReservationsByDay: StateFlow<Int> = _totalReservationsByDay
    private val _newReservations = MutableStateFlow<List<Reservation>>(emptyList())
    val newReservations: StateFlow<List<Reservation>> = _newReservations
    private val _selectedReservation = MutableStateFlow<Reservation?>(null)
    val selectedReservation: StateFlow<Reservation?> = _selectedReservation
    private val _totalNewReservations = MutableStateFlow<Int>(0)
    val totalNewReservations: StateFlow<Int> = _totalNewReservations

    private val reservationDao = AppDatabase.getDatabase(application).reservationDao()

    init {
        viewModelScope.launch {
            _allReservations.value = reservationDao.getAllReservations()
        }
    }

    fun addReservation(reservation: Reservation) {
        viewModelScope.launch {
            reservationDao.insert(reservation)

            //update variables to reflect the new reservation
            _allReservations.value = reservationDao.getAllReservations()
            val endOfDayToday = getEndOfDayInMillis(System.currentTimeMillis())
            val startOfDayToday = getStartOfDayInMillis(System.currentTimeMillis())
            _openReservationsToday.value =
                reservationDao.getTodayOpenReservations(endOfDay = endOfDayToday)
            _totalOpenReservationsToday.value =
                reservationDao.totalOpenTodayReservations(endOfDay = endOfDayToday)
            _openReservations.value = reservationDao.getOpenReservations()
            _totalOpenReservations.value = reservationDao.totalOpenReservations()
            val startOfDayReservation = getStartOfDayInMillis(reservation.dateReservation)
            val endOfDayReservation = getEndOfDayInMillis(reservation.dateReservation)
            _reservationsByDay.value =
                reservationDao.getReservationsByDay(startOfDayReservation, endOfDayReservation)
            _totalReservationsByDay.value =
                reservationDao.totalReservationsByDay(startOfDayReservation, endOfDayReservation)
            _totalNewReservations.value =
                reservationDao.totalNewReservations(startOfDayToday, endOfDayToday)

        }
    }

    fun deleteReservation(reservation: Reservation) {
        viewModelScope.launch {
            reservationDao.delete(reservation)

            //update variables to reflect the elimination of reservation
            _allReservations.value = reservationDao.getAllReservations()
            val endOfDayToday = getEndOfDayInMillis(System.currentTimeMillis())
            _openReservationsToday.value =
                reservationDao.getTodayOpenReservations(endOfDay = endOfDayToday)
            _totalOpenReservationsToday.value =
                reservationDao.totalOpenTodayReservations(endOfDay = endOfDayToday)
            _openReservations.value = reservationDao.getOpenReservations()
            _totalOpenReservations.value = reservationDao.totalOpenReservations()
            val startOfDayReservation = getStartOfDayInMillis(reservation.dateReservation)
            val endOfDayReservation = getEndOfDayInMillis(reservation.dateReservation)
            _reservationsByDay.value =
                reservationDao.getReservationsByDay(startOfDayReservation, endOfDayReservation)
            _totalReservationsByDay.value =
                reservationDao.totalReservationsByDay(startOfDayReservation, endOfDayReservation)

        }
    }

    fun updateReservation(reservation: Reservation) {
        viewModelScope.launch {
            reservationDao.update(reservation)

            //update variables to reflect the updated reservation
            _allReservations.value = reservationDao.getAllReservations()
            val endOfDayToday = getEndOfDayInMillis(System.currentTimeMillis())
            _openReservationsToday.value =
                reservationDao.getTodayOpenReservations(endOfDay = endOfDayToday)
            _openReservations.value = reservationDao.getOpenReservations()
            val startOfDayReservation = getStartOfDayInMillis(reservation.dateReservation)
            val endOfDayReservation = getEndOfDayInMillis(reservation.dateReservation)
            _reservationsByDay.value =
                reservationDao.getReservationsByDay(startOfDayReservation, endOfDayReservation)
        }
    }

    //list of open reservations in the current day
    fun getOpenReservationsToday() {
        viewModelScope.launch {
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _openReservationsToday.value =
                reservationDao.getTodayOpenReservations(endOfDay = endOfDay)
        }
    }

    //total open reservations in the current day
    fun getTotalOpenReservationsToday() {
        viewModelScope.launch {
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _totalOpenReservationsToday.value =
                reservationDao.totalOpenTodayReservations(endOfDay = endOfDay)
        }
    }

    //list of open reservations
    fun getOpenReservations() {
        viewModelScope.launch {
            _openReservations.value = reservationDao.getOpenReservations()
        }
    }

    //total open reservations
    fun getTotalOpenReservations() {
        viewModelScope.launch {
            _totalOpenReservations.value = reservationDao.totalOpenReservations()
        }
    }

    //reservations for a specific day
    fun getReservationsByDay(dayInMillis: Long) {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(dayInMillis)
            val endOfDay = getEndOfDayInMillis(dayInMillis)
            _reservationsByDay.value = reservationDao.getReservationsByDay(startOfDay, endOfDay)
        }
    }

    //total reservations by day
    fun getTotalReservationsByDay(dayInMillis: Long) {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(dayInMillis)
            val endOfDay = getEndOfDayInMillis(dayInMillis)
            _totalReservationsByDay.value =
                reservationDao.totalReservationsByDay(startOfDay, endOfDay)
        }
    }

    fun getTotalNewReservations() {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(System.currentTimeMillis())
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _totalReservationsByDay.value =
                reservationDao.totalNewReservations(startOfDay, endOfDay)
        }
    }

    fun getReservationsCreatedToday() {
        viewModelScope.launch {
            val startOfDay = getStartOfDayInMillis(System.currentTimeMillis())
            val endOfDay = getEndOfDayInMillis(System.currentTimeMillis())
            _newReservations.value =
                reservationDao.getReservationsCreatedToday(startOfDay, endOfDay)
        }
    }

    fun selectReservation(reservation: Reservation) {
        _selectedReservation.value = reservation
    }


}


