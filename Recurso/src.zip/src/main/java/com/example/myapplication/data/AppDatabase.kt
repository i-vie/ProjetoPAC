package com.example.myapplication.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.myapplication.data.dao.CategoryDao
import com.example.myapplication.data.dao.EmployeeDao
import com.example.myapplication.data.dao.OrderDao
import com.example.myapplication.data.dao.OrderItemDao
import com.example.myapplication.data.dao.ProductDao
import com.example.myapplication.data.dao.ReservationDao
import com.example.myapplication.data.dao.TableCountDao
import com.example.myapplication.data.entity.Category
import com.example.myapplication.data.entity.Employee
import com.example.myapplication.data.entity.Order
import com.example.myapplication.data.entity.OrderItem
import com.example.myapplication.data.entity.Product
import com.example.myapplication.data.entity.TableCount
import com.example.myapplication.data.entity.Reservation



@Database(entities =
[
    Category::class,
    Employee::class,
    Order::class,
    OrderItem::class,
    Product::class,
    TableCount::class,
    Reservation::class
],
    version = 18, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun orderDao(): OrderDao
    abstract fun orderItemDao(): OrderItemDao
    abstract fun productDao(): ProductDao
    abstract fun tableCountDao(): TableCountDao
    abstract fun reservationDao(): ReservationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gourmetmanager_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
