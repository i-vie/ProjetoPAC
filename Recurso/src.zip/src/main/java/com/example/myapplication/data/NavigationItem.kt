package com.example.myapplication.data

import com.example.myapplication.GourmetManagerScreen

data class NavigationItems(
    val screen: GourmetManagerScreen,
    val icon: Unit
)
