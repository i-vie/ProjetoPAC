package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color


val blue = Color(0xFF2E3C54)
val yellow = Color(0xfffbbc32)
val white = Color(0xFFF5F5F5)
val darkBlue = Color(0xff152033)
val grey = Color(0xffd9d9d9)
val disabledButtonColor = Color(0xFF9BA6B1)
val disabledButtonColorDark = Color(0xFFe1d6be)
val mediumGrey = Color(0xff999999)
val red = Color(0xFFC30000)

