package com.example.myapplication

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import com.example.myapplication.AppViewModel

import com.example.myapplication.GourmetManagerScreen
import com.example.myapplication.ui.theme.Poppins
import com.example.myapplication.ui.theme.grey
import com.example.myapplication.ui.theme.white
import com.example.myapplication.ui.theme.blue
import com.example.myapplication.ui.theme.yellow
import com.example.myapplication.R
import kotlinx.coroutines.delay

//login screen
@Composable
fun LoginScreen(
    navController: NavHostController,
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isUsernameValid by remember { mutableStateOf(true) }
    var isPasswordValid by remember { mutableStateOf(true) }


    Box(
    ){
        Canvas(modifier = Modifier.fillMaxSize()) {
            val path = Path().apply {
                moveTo(0f, size.height * 0.85f)
                lineTo(0f, size.height)
                lineTo(size.width, size.height)
                lineTo(size.width, 0f)
                lineTo(2000f, 150f)
                close()
            }
            drawPath(path, color = yellow)
        }
        Column(
            modifier = modifier

                .fillMaxSize()
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.padding_small))
            ) {
                Spacer(modifier = Modifier.height(150.dp))
                Image(
                    painter = painterResource(R.drawable.logo_vertical),
                    contentDescription = null,
                    modifier = Modifier.width(300.dp)
                )
                Spacer(modifier = Modifier.height(dimensionResource(R.dimen.padding_medium)))
                Spacer(modifier = Modifier.height(dimensionResource(R.dimen.padding_small)))
            }
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(
                    dimensionResource(id = R.dimen.padding_medium)
                )
            ) {
                UsernameTextField(
                    username,
                    isUsernameValid,
                    onValueChange = {
                        username = it
                        isUsernameValid = true
                    })
                PasswordTextField(
                    password,
                    isPasswordValid,
                    onValueChange = {
                        password = it
                        isPasswordValid = true
                    } )
                LoginButton(
                    username = username,
                    password = password,
                    onUsernameInvalid = { isUsernameValid = false },
                    onPasswordIncorrect = { isPasswordValid = false },
                    onLoginSuccess = {
                        isUsernameValid = true
                        isPasswordValid = true
                        navController.navigate(GourmetManagerScreen.Home.name)
                    },
                    viewModel = viewModel)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ForgotPassword(
                    onClick = {
                        navController.navigate(GourmetManagerScreen.ForgotPassword.name)
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))
                SignUp(
                    onClick = {
                        navController.navigate(GourmetManagerScreen.CreateAccount.name)
                    }
                )
            }

        }
    }
}

//button to go to the password recovery screen
@Composable
fun ForgotPassword(
    onClick: (Int) -> Unit
) {
    Text("Esqueceu-se da sua palavra-passe?", color = white)
    ClickableText(
        onClick = onClick,
        text = AnnotatedString("Clique aqui."),
        style = TextStyle(color = white, fontFamily = Poppins,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp)
    )
}



//button to login in the app
@Composable
fun LoginButton(
    username: String,
    password: String,
    onUsernameInvalid: () -> Unit,
    onPasswordIncorrect: () -> Unit,
    onLoginSuccess: () -> Unit,
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {

    var clicked by remember { mutableStateOf(false) }

    Button(
        onClick = {
            clicked = true
},
        colors = ButtonDefaults.buttonColors(blue),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
            .height(56.dp)
            .width(280.dp)
    ) {
        Text("Iniciar sessão",
            style = MaterialTheme.typography.labelSmall,
            color = white)
    }
    if (clicked) {
        LaunchedEffect(clicked) {
            viewModel.checkEmployee(username)
            delay(100)
            viewModel.checkPassword(password)
            delay(100)
            clicked = false
        }

        val employeeResult by viewModel.employeeResult.collectAsState()
        val passwordCheckResult by viewModel.passwordCheckResult.collectAsState()

        LaunchedEffect(employeeResult, passwordCheckResult) {
            when {
                username.isBlank() -> {
                    onUsernameInvalid()
                }
                employeeResult == null -> {
                    onUsernameInvalid()
                }
                password.isBlank() -> {
                    onPasswordIncorrect()
                }
                passwordCheckResult == false -> {
                    onPasswordIncorrect()
                }
                else -> {
                    val loggedInEmployee = employeeResult!!
                    viewModel.setLoggedInEmployee(loggedInEmployee)
                    onLoginSuccess()
                }
            }
        }
    }
}

@Composable
fun PasswordTextField(password: String, isPasswordValid: Boolean, onValueChange : (String) -> Unit) {


    Column (
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            modifier = Modifier
                .width(280.dp),
            value = password,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = "Palavra-passe", color = grey, fontFamily = Poppins,
                    fontWeight = FontWeight.Normal
                )
            },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = white,
                unfocusedContainerColor = white,
                focusedLabelColor = if (isPasswordValid) grey else MaterialTheme.colorScheme.error,
                unfocusedLabelColor = if (isPasswordValid) grey else MaterialTheme.colorScheme.error,
                focusedBorderColor = if (isPasswordValid) yellow else MaterialTheme.colorScheme.error,
                unfocusedBorderColor = if (isPasswordValid) blue else MaterialTheme.colorScheme.error
            ),
            shape = RoundedCornerShape(10.dp),
            maxLines = 1
        )
        LaunchedEffect (Unit) {
            delay(1000)
        }
        if (!isPasswordValid) {
            Text(
                text = "Palavra-passe inválida ou incorreta",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)
            )
        }
    }
}

@Composable
fun UsernameTextField(username: String, isUsernameValid: Boolean, onValueChange : (String) -> Unit) {

    Column (
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            modifier = Modifier
                .width(280.dp),
            value = username,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = "Email ou nome de utilizador",
                    color = grey,
                    fontFamily = Poppins,
                    fontWeight = FontWeight.Normal
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = white,
                unfocusedContainerColor = white,
                focusedLabelColor = if (isUsernameValid) grey else MaterialTheme.colorScheme.error,
                unfocusedLabelColor = if (isUsernameValid) grey else MaterialTheme.colorScheme.error,
                focusedBorderColor = if (isUsernameValid) yellow else MaterialTheme.colorScheme.error,
                unfocusedBorderColor = if (isUsernameValid) blue else MaterialTheme.colorScheme.error
            ),
            shape = RoundedCornerShape(10.dp),
            singleLine = true
        )
        LaunchedEffect (Unit) {
            delay(1000)
        }
        if (!isUsernameValid) {
            Text(
                text = "Nome de utilizador ou email inválido",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)
            )
        }
    }
}

//button to go to the create account screen
@Composable
fun SignUp(
    onClick: (Int) -> Unit
) {
    Text("Ainda não tem conta?", color = white)
    ClickableText(
        onClick = onClick,
        text = AnnotatedString("Inscreva-se aqui."),
        style = TextStyle(color = white, fontFamily = Poppins,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp)
    )
}

