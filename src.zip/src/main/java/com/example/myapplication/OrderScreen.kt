package com.example.myapplication

import android.app.Application
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Icon
import androidx.compose.material.Tab
import androidx.compose.material.TabRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.theme.GourmetManagerTheme
import com.example.myapplication.ui.theme.grey
import com.example.myapplication.ui.theme.white
import com.example.myapplication.ui.theme.blue
import com.example.myapplication.ui.theme.yellow
import com.example.myapplication.data.entity.Order
import com.example.myapplication.ui.theme.mediumGrey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


//order screen with the orders
@Composable
fun OrderScreen (
    navController: NavController,
    viewModel: AppViewModel,
    modifier: Modifier = Modifier) {

    var selectedTabIndex by remember { mutableStateOf(0) }
    //tabs for all open orders, orders for the current employee and all orders (open or closed)
    val tabTitles = listOf("Abertos", "Meus pedidos", "Todos")
    viewModel.getOpenOrders()
    viewModel.getMyOrders()
    viewModel.getAllOrders()
    val openOrders by viewModel.openOrders.collectAsState()
    val myOrders by viewModel.myOrders.collectAsState()
    val allOrders by viewModel.orderList.collectAsState()

    val orders = when (selectedTabIndex) {
        0 -> openOrders ?: emptyList()
        1 -> myOrders ?: emptyList()
        2 -> allOrders ?: emptyList()
        else -> emptyList()
    }

    val title = when (selectedTabIndex) {
        0 -> "Pedidos abertos"
        1 -> "Os meus pedidos"
        2 -> "Todos os pedidos"
        else -> ""
    }
    Column (
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
    ){
        TabRow(
            selectedTabIndex = selectedTabIndex,
            backgroundColor = blue,
            contentColor = white
            ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = { Text(title, color = white) }
                )
            }
        }

        Card (
            colors = CardDefaults.cardColors(
                containerColor = grey
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = modifier
                .fillMaxHeight()
                .padding(8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Title(title)
            Row (
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = {
                        viewModel.clearOrder()
                        navController.navigate(GourmetManagerScreen.CreateOrder.name)
                    },
                    colors = ButtonDefaults.buttonColors(
                        blue
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(
                        Icons.Rounded.Add, contentDescription = "", tint = white
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    androidx.compose.material.Text(
                        text = stringResource(id = R.string.new_order),
                        color = white,
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            orders.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    CardOrder(
                        order = item,
                        total = item.total,
                        onClick = ({
                            viewModel.selectOrder(item)
                            navController.navigate(GourmetManagerScreen.ViewDetails.name)
                            viewModel.getOrderItemsByOrderId(item.orderNr)
                            Log.d("OrderScreen", "Selected Order: ${item.orderNr} ${item.tableNr} ${item.total}")
                        }),
                        modifier = Modifier
                            .weight(1f)
                    )
                }
            }

        }
    }
}

@Composable
fun CardOrder(
    order: Order,
    total: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(white),
        border = BorderStroke(2.dp, yellow),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(8.dp)
    ) {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm",
            Locale.getDefault())
        val formattedDate = dateFormat.format(Date(order.date))
        val color = if (order.open) { blue } else { mediumGrey }
        Row {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .align(Alignment.CenterVertically)
            ) {
                Text(
                    text = order.orderNr.toString(),
                    style = MaterialTheme.typography.displayLarge,
                    color = color,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = order.tableNr,
                    style = MaterialTheme.typography.displaySmall,
                    color = color
                )
                Text(
                    text = formattedDate.substring(0, 10),
                    style = MaterialTheme.typography.bodyLarge,
                    color = color
                )
                if (!order.open) {
                    Text(
                        text = "Faturado",
                        style = MaterialTheme.typography.bodySmall,
                        color = color
                    )
                }
            }
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$total €",
                    style = MaterialTheme.typography.displaySmall,
                    color = color
                )
                Text(
                    text = formattedDate.substring(11),
                    style = MaterialTheme.typography.bodyLarge,
                    color = color
                )
            }
        }
    }
}

@Preview
@Composable
fun OrderScreenPreview() {
    GourmetManagerTheme {
        OrderScreen(
            navController = rememberNavController(),
            viewModel = AppViewModel(Application()),
            modifier = Modifier
                .fillMaxSize()
        )
    }
}