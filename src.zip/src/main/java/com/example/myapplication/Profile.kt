package com.example.myapplication

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.myapplication.ui.theme.blue
import com.example.myapplication.ui.theme.disabledButtonColor
import com.example.myapplication.ui.theme.grey

//current employee profile screen
@Composable
fun ProfileScreen(
    navController: NavController,
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val loggedInEmployee = viewModel.loggedInEmployee.value
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row {
            Column {
                Spacer(
                    modifier
                        .padding(16.dp)
                )
                Text(
                    text = "Nº de funcionário",
                    style = MaterialTheme.typography.bodyLarge,
                    color = blue,
                    modifier = modifier.padding(8.dp)
                )
                Text(
                    text = "Nome",
                    style = MaterialTheme.typography.bodyLarge,
                    color = blue,
                    modifier = modifier.padding(8.dp)
                )
                Text(
                    text = "Nome de utilizador",
                    style = MaterialTheme.typography.bodyLarge,
                    color = blue,
                    modifier = modifier.padding(8.dp)
                )
                Text(
                    text = "E-mail",
                    style = MaterialTheme.typography.bodyLarge,
                    color = blue,
                    modifier = modifier.padding(8.dp)
                )
                Text(
                    text = "Administrador",
                    style = MaterialTheme.typography.bodyLarge,
                    color = blue,
                    modifier = modifier.padding(8.dp)
                )
                Spacer(modifier.padding(24.dp))
            }
            Column {
                Spacer(
                    modifier
                        .padding(16.dp)
                )
                if (loggedInEmployee != null) {
                    Text(
                        text = "${loggedInEmployee.id}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = blue,
                        modifier = modifier.padding(8.dp)
                    )
                }
                if (loggedInEmployee != null) {
                    Text(
                        text = loggedInEmployee.name,
                        style = MaterialTheme.typography.bodyLarge,
                        color = blue,
                        modifier = modifier.padding(8.dp)
                    )
                }
                if (loggedInEmployee != null) {
                    Text(
                        text = loggedInEmployee.username,
                        style = MaterialTheme.typography.bodyLarge,
                        color = blue,
                        modifier = modifier.padding(8.dp)
                    )
                }
                if (loggedInEmployee != null) {
                    Text(
                        text = loggedInEmployee.email,
                        style = MaterialTheme.typography.bodyLarge,
                        color = blue,
                        modifier = modifier.padding(8.dp)
                    )
                }
                val text = if (loggedInEmployee?.admin == true) {
                    "Sim"
                } else {
                    "Não"
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = blue,
                    modifier = modifier.padding(8.dp)
                )
                Spacer(modifier.padding(24.dp))
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Button(
                onClick = {
                    navController.navigate(GourmetManagerScreen.ChangePassword.name)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = blue,
                    disabledContainerColor = disabledButtonColor
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .wrapContentHeight()
                    .padding(start = 16.dp)

            ) {
                Text("Alterar palavra-passe", style = MaterialTheme.typography.labelSmall)
            }

        }
    }
}