package com.example.myapplication.data.dao

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.room.*
import com.example.myapplication.data.entity.Employee
import com.example.myapplication.data.entity.Order

@Dao
interface OrderDao {
    @Insert
    suspend fun insert(order: Order) : Long

    @Query("SELECT * FROM orders ORDER BY open DESC")
    suspend fun getAllOrders(): List<Order>

    @Query("SELECT * FROM orders WHERE orderNr = :orderNr")
    suspend fun getOrderById(orderNr: Int): Order?

    @Query("SELECT * FROM orders WHERE open = 1")
    suspend fun getOpenOrders(): List<Order>

    @Query("SELECT * FROM orders WHERE employeeId = :employeeId ORDER BY open DESC")
    suspend fun getOrdersByEmployeeId(employeeId: Int): List<Order>

    @Delete
    suspend fun delete(order: Order)

    @Update
    suspend fun update(order: Order)

    @Query("UPDATE orders SET total = :newTotal WHERE orderNr = :orderNr")
    suspend fun updateOrderTotal(orderNr: Int, newTotal: Float)

    @Query("UPDATE orders SET tableNr = :newTable WHERE orderNr = :orderNr")
    suspend fun updateOrderTable(orderNr: Int, newTable: String)

    @Query("SELECT COUNT(*) FROM orders")
    suspend fun totalOrders(): Int

    @Query("SELECT COUNT(*) FROM orders WHERE open = 1")
    suspend fun totalOpenOrders(): Int

    @Query("SELECT COUNT(*) FROM orders WHERE open = 0")
    suspend fun totalClosedOrders(): Int

    @Query("SELECT SUM(total) FROM orders WHERE open = 0")
    suspend fun totalClosedOrdersPrice(): Double

    @Query("UPDATE orders SET open = 0 WHERE orderNr = :orderNr")
    suspend fun closeOrder(orderNr: Int)

    @Query("SELECT COUNT(*) FROM orders WHERE date >= :startOfDay AND date < :endOfDay")
    suspend fun totalOrdersToday(startOfDay: Long, endOfDay: Long): Int

    @Query("SELECT COUNT(*) FROM orders WHERE open = 1 AND date >= :startOfDay AND date < :endOfDay")
    suspend fun totalOpenOrdersToday(startOfDay: Long, endOfDay: Long): Int

    @Query("SELECT COUNT(*) FROM orders WHERE open = 0 AND date >= :startOfDay AND date < :endOfDay")
    suspend fun totalClosedOrdersToday(startOfDay: Long, endOfDay: Long): Int

    @Query("SELECT SUM(total) FROM orders WHERE open = 0 AND date >= :startOfDay AND date < :endOfDay")
    suspend fun totalOrdersPriceToday(startOfDay: Long, endOfDay: Long): Double
}